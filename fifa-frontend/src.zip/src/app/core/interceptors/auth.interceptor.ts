import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

/**
 * Interceptor HTTP para manejar credenciales (cookies)
 * Agrega automáticamente withCredentials: true a todas las peticiones
 */
@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  /**
   * Intercepta las peticiones HTTP
   * @param request Petición HTTP
   * @param next Handler para continuar con la cadena
   */
  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // Clona la petición y agrega credenciales
    const clonedRequest = request.clone({
      withCredentials: true
    });

    return next.handle(clonedRequest);
  }
}
