import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlayersService, Player, PlayersResponse } from '../services/players.service';

@Component({
  selector: 'app-player-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './player-list.component.html',
  styleUrl: './player-list.component.css'
})
export class PlayerListComponent implements OnInit {

  // 📊 Datos
  players: Player[] = [];
  isLoading = false;
  errorMessage = '';
  
  // 📑 Paginación
  currentPage = 1;
  limit = 10;
  totalPages = 0;

  constructor(private playersService: PlayersService) {}

  /**
   * Se ejecuta cuando el componente se inicializa
   * Carga la lista de jugadores
   */
  ngOnInit(): void {
    this.loadPlayers();
  }

  /**
   * Carga los jugadores desde el backend
   */
  loadPlayers(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.playersService.getPlayers(this.currentPage, this.limit).subscribe({
      next: (response: PlayersResponse) => {
        this.players = response.data;
        this.totalPages = response.totalPages;
        this.isLoading = false;
      },
      error: (error) => {
        this.errorMessage = 'Error al cargar jugadores';
        console.error(error);
        this.isLoading = false;
      }
    });
  }

  /**
   * Elimina un jugador
   */
  deletePlayer(id: number): void {
    if (!confirm('¿Estás seguro de eliminar este jugador?')) return;

    this.playersService.deletePlayer(id).subscribe({
      next: () => {
        this.loadPlayers(); // Recarga la lista
      },
      error: (error) => {
        this.errorMessage = 'Error al eliminar jugador';
        console.error(error);
      }
    });
  }

  /**
   * Navega a la página anterior
   */
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadPlayers();
    }
  }

  /**
   * Navega a la página siguiente
   */
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.loadPlayers();
    }
  }
}
