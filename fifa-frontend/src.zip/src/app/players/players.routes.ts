import { Routes } from '@angular/router';
import { PlayerListComponent } from './player-list/player-list.component';

/**
 * Rutas de jugadores
 * - Ruta raíz: Lista de jugadores
 * - Ruta detalle: Detalle/Edición de jugador
 */
export const PLAYERS_ROUTES: Routes = [
  {
    path: '',
    component: PlayerListComponent
  }
  // Próximamente:
  // {
  //   path: ':id',
  //   component: PlayerDetailComponent
  // }
];
