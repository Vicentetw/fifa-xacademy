import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'players',
    pathMatch: 'full'
  },
  {
    path: 'auth',
    loadComponent: () =>
    import('./auth/login/login.component')
      .then(m => m.LoginComponent)
  },
  {
    path: 'players',
    loadChildren: () => import('./players/players.routes').then(m => m.PLAYERS_ROUTES)
  }
];