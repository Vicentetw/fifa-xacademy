import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';

/**
 * Rutas de autenticación
 * - login: Formulario de login
 * - register: Formulario de registro (próximamente)
 */
export const AUTH_ROUTES: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: LoginComponent // Por ahora reutilizamos login, se cambiará en fase 4
  }
];
